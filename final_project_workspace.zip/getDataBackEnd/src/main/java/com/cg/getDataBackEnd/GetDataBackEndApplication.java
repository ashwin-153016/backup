package com.cg.getDataBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetDataBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetDataBackEndApplication.class, args);
	}
}
