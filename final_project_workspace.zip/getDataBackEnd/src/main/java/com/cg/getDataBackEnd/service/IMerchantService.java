package com.cg.getDataBackEnd.service;

import java.util.List;

import com.cg.getDataBackEnd.model.Merchant;

public interface IMerchantService {

	public List<Merchant> getAll();
}
