package com.cg.getDataBackEnd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.getDataBackEnd.model.Merchant;
import com.cg.getDataBackEnd.service.IMerchantService;;

@RestController
@RequestMapping("/api/v1/")
public class MerchantRestController {

	@Autowired
	private IMerchantService merchantService;
	
	@GetMapping("/merchants")
	public ResponseEntity<List<Merchant>> getAllPilots(){
		List<Merchant> merchants= merchantService.getAll();
		if(merchants.isEmpty()||merchants==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Merchant>>(merchants,HttpStatus.OK);
	}
}
