package com.cg.getDataBackEnd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.getDataBackEnd.dao.MerchantDao;
import com.cg.getDataBackEnd.model.Merchant;

@Service("merchantService")
public class MerchantServiceImpl implements IMerchantService {

	@Autowired
	private MerchantDao merchantDao;
	
	@Override
	public List<Merchant> getAll() {
		
		return merchantDao.findAll();
	}

}
