package com.cg.getDataFrontEnd.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cg.getDataFrontEnd.model.Merchant;

@Controller
public class MerchantController {

	@RequestMapping("/")
	public String getMerchnatPage(ModelMap map) {
		
		final String uri="http://localhost:8111/MerchantRest/api/v1/merchants";
		RestTemplate restTemplate=new RestTemplate();
		
		Merchant[] merchants= restTemplate.getForObject(uri, Merchant[].class);
		
		
		map.put("merchants",merchants);
		map.put("merchant", new Merchant());
		
	
		return "validateMerchant";
	}
	
}
