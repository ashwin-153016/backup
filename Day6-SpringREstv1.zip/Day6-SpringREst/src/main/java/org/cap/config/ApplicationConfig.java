package org.cap.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@ComponentScan({"org.cap"})
@EnableTransactionManagement
public class ApplicationConfig {
	
	@Bean
	public LocalEntityManagerFactoryBean getEntityManagerFactoryBean() {
		LocalEntityManagerFactoryBean factoryBean=new LocalEntityManagerFactoryBean();
		factoryBean.setPersistenceUnitName("jpademo");
		return factoryBean;
	}

	@Bean
	public JpaTransactionManager getTranactionManager() {
		JpaTransactionManager transManager=new JpaTransactionManager();
		transManager.setEntityManagerFactory(getEntityManagerFactoryBean().getObject());
		
		return transManager;
	}
	

}
