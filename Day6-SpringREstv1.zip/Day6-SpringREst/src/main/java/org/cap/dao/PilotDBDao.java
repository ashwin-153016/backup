package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDbDao")
public class PilotDBDao implements PilotDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public List<Pilot> getAllPilots() {
		List<Pilot> pilots=entityManager.createQuery("from Pilot").getResultList();
		return pilots;
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		Pilot pilot=entityManager.find(Pilot.class,pilotId );
		return pilot;
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		Pilot pilot= entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
		return getAllPilots();
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		entityManager.persist(pilot);
		return getAllPilots();
		
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		Pilot pilot1= entityManager.find(Pilot.class, pilot.getPilotId());
		if(pilot1==null)
		{
			entityManager.persist(pilot);
		}
		else
		entityManager.merge(pilot);
		return getAllPilots();
	}

}
