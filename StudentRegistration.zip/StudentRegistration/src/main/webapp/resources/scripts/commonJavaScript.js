function validateForm(){
	
	firstName = registrationForm.firstName.value;
	lastName  = registrationForm.lastName.value;
	address   = registrationForm.address.value;
	city	  = registrationForm.city.value;
	state	  = registrationForm.state.value;
	gender	  = registrationForm.gender.value;
	course	  = registrationForm.course.value;
	mobile    = registrationForm.mobile.value;
	
	
	if(checkName(firstName)){
		
		if(checkName(lastName)){
			
			if(checkAddress(address)){
			  
				if(checkGender(gender)){
				
					if(checkMobile(mobile)){
						window.location = window.location.href + 'payment';
					}
					else{
							alert("Please enter valid 10 digit mobile number.");
					}
				}
				else{
					alert("Please  select gender");
				}
			}
			else{
				alert( "Please enter address");
			}
			
		}
		else{
			alert("Please enter Name with first Uppercase and only alphabets are allowed");
		}
	}
	else{
		alert("Please enter Name with first Uppercase and only alphabets are allowed");
	}

}

function checkName(name){
	
	validFormat = /^[A-Z][a-z]{3,}$/;
	
	if(name=='' || name==null || !name.match(validFormat)){
		return false;
	}
 return true;
}

function checkAddress(address){
	if(address=="" || address==null){
		return false;
	}
	
 return true;
}

function checkMobile(mobile){
	var mobileFormat = /^\d{10}$/;
	if(mobile=="" || mobile==null || !mobile.match(mobileFormat)){
		return false;
	}
return true;
}

function checkGender(gender){
	if(gender=="" || gender == null){
		return false;
	}
 return true;
}


function validatePayment(){
	
	var cardholder = paymentForm.cardholderName.value;
	var cardNumber = paymentForm.cardNumber.value;
	var cvv = paymentForm.cvvNumber.value;
	var month = paymentForm.month.value;
	var year = paymentForm.years.value;

	
	if(checkCapsName(cardholder)){
		
		if(checkCardNumber(cardNumber)){
		
			if(checkCvv(cvv)){
				alert("Your payment is Successfull!!");
			}
			else{
				alert("Please enter valid 3 digit cvv number.");
			}
		}
		else{
			alert("Please enter valid 16 digit card number.");
		}
	}
	else{
		alert("Please enter name in all Upper case. Only alphabets allowed.");
	}
	
	
}


function checkCapsName(name){
	
	validFormat = /^[A-Z]{2,}$/;
	
	if(name=="" || name==null || !name.match(validFormat)){
		return false;
	}
 return true;
}

function checkCardNumber(number){
	var cardFormat=/^\d{16}$/;
	
	if(number=="" || number==null || !number.match(cardFormat)){
		return false;
	}
 return true;
}

function checkCvv(cvv){
var cardFormat=/^\d{3}$/;
	
	if(cvv=="" || cvv==null || !cvv.match(cardFormat)){
		return false;
	}
 return true;
}