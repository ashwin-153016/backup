package org.cap.controller;

import javax.servlet.http.HttpSession;

import org.cap.dao.AccountDao;
import org.cap.model.Account;
import org.cap.service.LoginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private AccountDao accountDao;
	
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, @RequestParam("customerId") String id, @RequestParam("customerPwd") String customerPwd,HttpSession session) {
		
		int customerId = Integer.parseInt(id);
		
		if(loginService.loginValidate(customerId, customerPwd)) {
			
			String name = loginService.getCustomerName(customerId);
			map.put("customerName", name);
			session.setAttribute("customerId", customerId);
			return "main";
		}
		return "redirect:/";
	}
	

	@RequestMapping("/welcomePage")
	public String welcomePage(ModelMap map, HttpSession session) {
	

		String name = loginService.getCustomerName(Integer.parseInt(session.getAttribute("customerId").toString()));
		map.put("customerName", name);

		return "welcomePage";
	}
	

	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {
		map.put("account", new Account());
		return "createAccount";
	}
	
	@RequestMapping("/showBalance")
	public String showBalancePage() {
		return "showBalance";
	}

	@RequestMapping("/deposit")
	public String showDepositPage() {
		return "deposit";
	}

	@RequestMapping("/withdraw")
	public String showWithdrawPage() {
		return "withdraw";
	}

	@RequestMapping("/fundTransfer")
	public String showFundTransferPage() {
		return "fundTransfer";
	}

	@RequestMapping("/printTransaction")
	public String showPrintTransactionPage() {
		return "printTransaction";
	}

	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
	 return "redirect:/";
	}
	
	@PostMapping("/saveAccount")
	public String saveAccount(@ModelAttribute("account") Account account, HttpSession session) {
		
		return "";
	}
	
	
}
