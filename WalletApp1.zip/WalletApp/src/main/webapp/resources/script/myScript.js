function bodyOnLoad(){
	document.getElementById("yearsDiv").style.display="none";
	document.getElementById("years").style.display="none";
}

function validateForm(){
	
	var uname = myform.customerId.value;
	var upwd = myform.customerPwd.value;
	var flag = false;
	
	if(uname==""||uname==null){
		document.getElementById('userErrMsg').innerHTML=" * Please enter userName.";
		document.getElementById('pwdErrMsg').innerHTML="";
	}
	
	else if(upwd=="" || upwd==null)
		{
		flag=false;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML=" * Please enter password.";
	}
	
	else{
		flag=true;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML="";
	}
	
	return flag;
}

function showYearsDiv(){
	
	if(document.getElementById("rd").checked || document.getElementById("fd").checked){
		document.getElementById("yearsDiv").style.display="block";
		document.getElementById("years").style.display="block";
	}
	else{
		document.getElementById("yearsDiv").style.display="none";
		document.getElementById("years").style.display="none";
	}
}
