package org.cap.Dao;

import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface AccountDao {
	public void createAccount(Account account);
    public List<Account> getAllAccounts(int customerId);
	public Map<Account, Double> getAmoutCrDe(String str, int custId);
	public Account findAccount(long accnum);
	public void depositWith(Transaction transaction);
	public void FundTransfer(Transaction transaction);
	public List<Account> getOtherAccount(Integer customerId);
	public Account findAccount1(long accnum1);
}
