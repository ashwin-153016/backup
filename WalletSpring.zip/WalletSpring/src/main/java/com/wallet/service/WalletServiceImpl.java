package com.wallet.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wallet.dao.WalletDao;
import com.wallet.model.Account;
import com.wallet.model.Transaction;

@Service("walletService")
public class WalletServiceImpl implements WalletService {

	@Autowired
	private WalletDao walletDao;
	
	@Override
	public void createAcc(Account account) {
		walletDao.createAcc(account);

	}

	@Override
	public List<Account> getAllAcc(int custId) {
		return walletDao.getAllAcc(custId);
	}

	
	@Override
	public List<Account> getAccWithBalance(int custId) {
		String str="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='debit'";
		Map<Account, Double> debitMap = walletDao.getAmountCrDe(str,custId);

	String str1="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='credit'";
	Map<Account, Double> creditMap = walletDao.getAmountCrDe(str1,custId);
		

	List<Account> accounts=getAllAcc(custId);
	
	Iterator<Account> iterator= accounts.iterator();
	while(iterator.hasNext()) {
		Account account=iterator.next();
		double balance=0;
		double creditAmt=0,debitAmt=0;
		account.setUpdateBalance(0);
		
		if(creditMap.get(account) ==null)
			creditAmt=0;
		else
			creditAmt=creditMap.get(account);
		

		if( debitMap.get(account) ==null)
			debitAmt=0;
		else
			debitAmt= debitMap.get(account);
		
		
		
		balance=account.getOpeningBalance() +
				creditAmt-debitAmt;
		
		account.setUpdateBalance(balance);
		
	}
	return accounts;
	}

	@Override
	public void addTransaction(Transaction transaction) {
		walletDao.addTransaction(transaction);
		
	}

	@Override
	public Account findAccount(long accountNo) {
		
		return walletDao.findAccount(accountNo);
	}

	@Override
	public List<Transaction> getTransactions(Integer id) {
		return walletDao.getTransactions(id);
	}
	


	@Override
	public Account getAccount(long accNo) {
		
		return walletDao.getAccount(accNo);
	}

	@Override
	public Account getAccount1(long accNo1) {
		
		return walletDao.getAccount1(accNo1);
	}

	@Override
	public void fundTransfer(Transaction transaction) {
		walletDao.fundTransfer(transaction);
		
	}

	@Override
	public List<Account> getAllToAccounts(Integer customerId) {
		
		return walletDao.getAllToAccounts(customerId);
	}
	
}
