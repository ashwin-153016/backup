package com.wallet.dao;

import java.util.List;
import java.util.Map;

import com.wallet.model.Account;
import com.wallet.model.Transaction;

public interface WalletDao {

	public void createAcc(Account account);
	public List<Account> getAllAcc(int custId);
	public Map<Account, Double> getAmountCrDe(String strQuery,int customerId);
	public void addTransaction(Transaction transaction1);
	public Account findAccount(long accountNo);
	public List<Transaction> getTransactions(Integer id);
	public void fundTransfer(Transaction transaction);
	public Account getAccount(long accNo);
	public Account getAccount1(long accNo1);
	public List<Account> getAllToAccounts(Integer customerId);

}
