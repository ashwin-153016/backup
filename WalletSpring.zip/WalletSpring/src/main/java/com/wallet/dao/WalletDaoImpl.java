package com.wallet.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wallet.model.Account;
import com.wallet.model.Transaction;

@Repository("walletDao")

public class WalletDaoImpl implements WalletDao {
	
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager em;
	
	@Override
	@Transactional
	public void createAcc(Account account) {
		Query query= em.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		
		System.out.println(account);
		
		em.persist(account);
		
	}

	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAcc(int customerId) {
		Query query= em.createQuery("from Account acc where acc.customer.customerId=:custId");
		query.setParameter("custId", customerId);
		Query query2=em.createQuery("from Transaction trans where trans.customer.customerId=:custId");
		query2.setParameter("custId", customerId);
		List<Account> accounts= query.getResultList();
		List<Transaction> transactions=query2.getResultList();
		return accounts;
	}

	@Override
	@Transactional(readOnly=true)
	public Map<Account, Double> getAmountCrDe(String strQuery, int customerId) {
		Query query=em.createQuery(strQuery);
		query.setParameter("custId", customerId);
		
		List<Transaction> transactions=query.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount))
				);
		return map;

	}
	
	@Transactional
	public void addTransaction(Transaction transaction1) {
		em.persist(transaction1);
		
	}

	@Override
	@Transactional
	public Account findAccount(long accountNo) {
		Query query= em.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accountNo);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}
	
	@Transactional
	@Override
	public List<Transaction> getTransactions(Integer id) {
		Query q4= em.createQuery("from Transaction tx where tx.customer.customerId=:cust");
		q4.setParameter("cust", id);
			List<Transaction> transaction= q4.getResultList();
		for (Transaction transaction2 : transaction) {
			System.out.println(transaction2);
		}
		return transaction;
		
	}

	@Override
	public Account getAccount(long accountNo) {
		Query query= em.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accountNo);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllToAccounts(Integer customerId) {
		Query query=em.createQuery("from Account acc where acc.customer.customerId!=:custId");
		query.setParameter("custId", customerId);
		
		List<Account> accounts=query.getResultList();
		
		return accounts;
		
	}

	@Override
	@Transactional
	public void fundTransfer(Transaction transaction) {
		em.persist(transaction);
		
		
	}

	@Override
	public Account getAccount1(long accNo1) {
		Query query= em.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accNo1);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}

}
