package org.cap.student;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student {

	@Id
	@GeneratedValue
	private int studentId;
	
	private String studentName;
	private String studentLocation;
	private String studentBranch;
	
	
	public Student(int studentId, String studentName, String studentLocation, String studentBranch) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentLocation = studentLocation;
		this.studentBranch = studentBranch;
	}


	public Student() {
		super();
	}


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getStudentName() {
		return studentName;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}


	public String getStudentLocation() {
		return studentLocation;
	}


	public void setStudentLocation(String studentLocation) {
		this.studentLocation = studentLocation;
	}


	public String getStudentBranch() {
		return studentBranch;
	}


	public void setStudentBranch(String studentBranch) {
		this.studentBranch = studentBranch;
	}


	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentLocation="
				+ studentLocation + ", studentBranch=" + studentBranch + "]";
	}
	

	
}
