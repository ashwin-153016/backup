package org.cap.service;

import java.util.List;

import org.cap.student.Student;

public interface StudentService {
	public List<Student> getStudents();
	public Student findStudent(Integer studentId);
	public void update(Student student);
}
