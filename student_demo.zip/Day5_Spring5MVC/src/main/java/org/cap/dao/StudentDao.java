package org.cap.dao;

import java.util.List;

import org.cap.student.Student;

public interface StudentDao {

	public List<Student> getStudents();
	public Student findStudent(Integer studentId);
	public void update(Student student);
}
