package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.cap.student.Student;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("studentDao")
@Transactional
public class StudentDaoImpl implements StudentDao {

	@PersistenceContext
	private EntityManager entityManager; 
	
	
	@Transactional(readOnly=true)
	@Override
	public List<Student> getStudents() {
	
		List<Student> students = entityManager.createQuery("from Student").getResultList();
		
		return students;
	}


	@Override
	public Student findStudent(Integer studentId) {
		Student student = entityManager.find(Student.class, studentId);
		return student;
	}


	@Override
	public void update(Student student) {
		Student student1 = entityManager.find(Student.class, student.getStudentId());
		if(student1!= null) {
			entityManager.merge(student);
		}
		else {
			entityManager.persist(student);
		}
		
	}

}
