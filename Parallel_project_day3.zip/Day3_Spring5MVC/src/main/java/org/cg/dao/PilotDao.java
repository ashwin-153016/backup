package org.cg.dao;

import java.util.List;

import org.cg.model.Pilot;

public interface PilotDao 
{
	public void save(Pilot pilot);
	
	public List<Pilot> getAll();
	public void delete(Integer pilotId);
	public Pilot validateLogin(String userName, String userPassword);
}
