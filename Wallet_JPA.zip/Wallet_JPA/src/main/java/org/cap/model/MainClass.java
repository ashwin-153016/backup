package org.cap.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager = factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer=new Customer();
		customer.setCustomerPwd("tom123");
		customer.setFirstName("Tom");
		customer.setLastName("Jerry");
		customer.setLastLoginDate(new Date());
		
		
		Account account=new Account();
		account.setAccountNo(32432432432L);
		account.setAccountType("savings");
		
	
		account.setCustomer(customer);
		
		Account account1=new Account();
		account1.setAccountNo(32435435L);
		account1.setAccountType("current");
		account1.setCustomer(customer);
		
		Account account2=new Account();
		account2.setAccountNo(32435455L);
		account2.setAccountType("rd");
		account2.setCustomer(customer);
		account2.setYears(2);
		
		Transaction transaction2=new Transaction();
		transaction2.setCustomer(customer);
		transaction2.setFromAccount(account);
		transaction2.setAmount(1000);
		transaction2.setTransactionType("debit");
		transaction2.setTransactionDate(new Date());
		
		
		Transaction transaction3=new Transaction();
		transaction3.setCustomer(customer);
		transaction3.setFromAccount(account);
		transaction3.setToAccount(account1);
		transaction3.setAmount(1000);
		transaction3.setTransactionType("credit");
		transaction3.setTransactionDate(new Date());
		
		entityManager.persist(customer);
		entityManager.persist(account);
		entityManager.persist(account1);
		entityManager.persist(account2);
		entityManager.persist(transaction2);
		entityManager.persist(transaction3);
		transaction.commit();


	}

}
