package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface AccountService {
	public void createAccount(Account account);
	public List<Account> getAllAccount(Integer id);
	public List<Account> getAccountWithBalance(int custId);
	public void createTransactionAccount(Transaction account);
	public List<Transaction> getTransactions(Integer id);

}
