package org.cap.service;

import java.util.List;

import org.cap.dao.WalletDao;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("walletService")
public class WalletServiceImpl implements WalletService{
    @Autowired
    private WalletDao walletDao;
/*	@Override
	public Customer getLogin(String uname, Integer password) {
		// TODO Auto-generated method stub
		return walletDao.getLogin(uname, password);
	}*/
	/*@Override
	public void saveAccount(Account acc) {
		// TODO Auto-generated method stub
		walletDao.saveAccount(acc);
	}

@Override
public List<Account> getAllAccount(Integer id) {
	// TODO Auto-generated method stub
	return walletDao.getAllAccount(id);
}
@Override
public Account find(Integer id) {
	// TODO Auto-generated method stub
	return walletDao.find(id);
}*/
@Override
public String getCustomerName(Integer id) {
	// TODO Auto-generated method stub
	return walletDao.getCustomerName(id);
}

@Override
public List<Customer> getLogin(Integer id, String Password) {
	// TODO Auto-generated method stub
	return walletDao.getLogin(id, Password);
}
	

}
