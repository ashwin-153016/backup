package org.cap.dao;

import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface AccountDao {
	public void createAccount(Account account);
	public List<Account> getAllAccount(Integer id);
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId);
	public void createTransactionAccount(Transaction account);
	public void depositWithdraw(Transaction transaction);
	public List<Transaction> getTransactions(Integer id);
}
