package org.cap.model;

import java.util.List;

public class Equipment {
private String equipTag;
private long seqNumber;
private int userId;
private int machineId;
private String location;
private int quantity;
private String equipType;
private String status;
private List <Users> users;
public String getEquipTag() {
	return equipTag;
}
public void setEquipTag(String equipTag) {
	this.equipTag = equipTag;
}
public long getSeqNumber() {
	return seqNumber;
}
public void setSeqNumber(long seqNumber) {
	this.seqNumber = seqNumber;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public int getMachineId() {
	return machineId;
}
public void setMachineId(int machineId) {
	this.machineId = machineId;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public String getEquipType() {
	return equipType;
}
public void setEquipType(String equipType) {
	this.equipType = equipType;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public List<Users> getUsers() {
	return users;
}
public void setUsers(List<Users> users) {
	this.users = users;
}
public Equipment(String equipTag, long seqNumber, int userId, int machineId, String location, int quantity,
		String equipType, String status, List<Users> users) {
	super();
	this.equipTag = equipTag;
	this.seqNumber = seqNumber;
	this.userId = userId;
	this.machineId = machineId;
	this.location = location;
	this.quantity = quantity;
	this.equipType = equipType;
	this.status = status;
	this.users = users;
}
public Equipment() {
	super();
}
@Override
public String toString() {
	return "Equipment [equipTag=" + equipTag + ", seqNumber=" + seqNumber + ", userId=" + userId + ", machineId="
			+ machineId + ", location=" + location + ", quantity=" + quantity + ", equipType=" + equipType + ", status="
			+ status + ", users=" + users + "]";
}



}
