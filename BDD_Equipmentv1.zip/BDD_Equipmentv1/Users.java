package org.cap.model;

public class Users {
private String user;

public String getUser() {
	return user;
}

public void setUser(String user) {
	this.user = user;
}

public Users(String user) {
	super();
	this.user = user;
}

public Users() {
	super();
}

}
