package org.cap.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("pilotDao")
@Transactional
public class PilotDaoImp implements PilotDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public void save(Pilot pilot) {
		
		if(pilot.getPilotId()!=0)
			entityManager.merge(pilot);
		else
			entityManager.persist(pilot);
	}
	
	
	@Override
	@Transactional(readOnly=true)
	public List<Pilot> getAll() {
		List<Pilot> pilots=entityManager.createQuery("from Pilot").getResultList();
		return pilots;
	}

	
	@Override
	@Transactional
	public void delete(Integer pilotId) {
		Pilot pilot= entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
	}
	
	
	@Override
	@Transactional
	public Pilot findPilot(Integer ptId) {
		Pilot pilot=entityManager.find(Pilot.class,ptId);
		return pilot;
	}
	
	
	@Override
	@Transactional
	public void update(Pilot pilot) {
	 Pilot pilot1 = entityManager.find(Pilot.class, pilot.getPilotId());
	 
		if(pilot1 != null)
			entityManager.merge(pilot);
		else
			entityManager.persist(pilot);
		
		
	}

}
