package com.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		return new ModelAndView("helloPage","msg","Hello! Good Afternoon.");
	}
	
	@RequestMapping("/validateLogin")
	public String validatelogin(Model map,@RequestParam("username")String username, @RequestParam("password") String password) {
		if(username.equals("tom") && password.equals("tom123")) {
			return "helloPage";
		}
		return "redirect:/";
	}
	/*@RequestMapping("/")
	public String loginForm() {
		return "index";
	}*/
	
}
