package com.cap.service;

public interface PilotService {

}
