package com.cap.dao;

public interface PilotDao {

}
