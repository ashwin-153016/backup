package com.cap.dao;

public class PilotDaoImpl implements PilotDao{

}
