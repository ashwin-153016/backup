package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import javax.validation.constraints.Email;
import org.hibernate.validator.constraints.Range;

@Entity
//@Table(name="pilot")
public class Pilot {

@Id
@GeneratedValue
private int pilotId;

@NotNull(message="**Please enter pilot Fristname")
private String fristName;

@NotNull(message="**Please enter pilot Lastname")
private String lastName;

@NotNull(message="*Enter date of birth")
@Past(message="*Enter the past date")
private Date dob;

@NotNull(message="*Enter email id")
@Email(message="*Enter a valid email Id")
private String emailId;

@NotNull(message="enter date of joining")
@Future(message="*Enter the future date")
private Date doj;

@NotNull(message="*select either yes or no.")
private Boolean isCerti;

@Range(min=1000,max=200000,message="*salary should be between 1000 and 2lakhs.")
private double salary;

public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public int getPilotId() {
	return pilotId;
}
public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}
public String getFristName() {
	return fristName;
}
public void setFristName(String fristName) {
	this.fristName = fristName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public Date getDoj() {
	return doj;
}
public void setDoj(Date doj) {
	this.doj = doj;
}

public Boolean getIsCerti() {
	return isCerti;
}
public void setIsCerti(Boolean isCerti) {
	this.isCerti = isCerti;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "pilot [pilotId=" + pilotId + ", fristName=" + fristName + ", lastName=" + lastName + ", dob=" + dob
			+ ", doj=" + doj + ", isCerti=" + isCerti + ", salary=" + salary + "]";
}
public Pilot(int pilotId, String fristName, String lastName, Date dob,String emailId, Date doj, Boolean isCerti,
		double salary) {
	super();
	this.pilotId = pilotId;
	this.fristName = fristName;
	this.lastName = lastName;
	this.dob = dob;
	this.emailId=emailId;
	this.doj = doj;
	this.isCerti = isCerti;
	this.salary = salary;
}
public Pilot() {
	super();
}
}