package org.cap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day7SpringBootPilotApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day7SpringBootPilotApplication.class, args);
	}
}
