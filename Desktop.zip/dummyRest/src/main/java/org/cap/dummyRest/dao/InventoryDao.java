package org.cap.dummyRest.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.dummyRest.model.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Transactional
@Repository("inventoryDao")
public interface InventoryDao extends JpaRepository<Inventory,Integer> {
	

}
