package org.cap.dummyRest.service;

import java.util.List;

import org.cap.dummyRest.dao.InventoryDao;
import org.cap.dummyRest.model.Inventory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Service("inventoryService")
public class InventoryServiceImpl implements InventoryService{
	
	@Autowired
	private InventoryDao inventoryDao;



	@Override
	public List<Inventory> getAll() {
		
		return inventoryDao.findAll();
	}



	
	
}
