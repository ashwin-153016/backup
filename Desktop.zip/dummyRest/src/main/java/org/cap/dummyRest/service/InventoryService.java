package org.cap.dummyRest.service;

import java.util.List;

import org.cap.dummyRest.model.Inventory;


public interface InventoryService {
	
	public List<Inventory> getAll();

	
}
