package org.cap.dummyRest.controller;

import java.util.List;

import org.cap.dummyRest.model.Inventory;
import org.cap.dummyRest.service.InventoryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class DummyController {
	

	@Autowired
	private InventoryService inventoryService;
	
	@GetMapping("/inventories")
	public ResponseEntity<List<Inventory>> getAllProducts(){
		List<Inventory> inventories= inventoryService.getAll();
		if(inventories.isEmpty()||inventories==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Inventory>>(inventories,HttpStatus.OK);
	}
	
	
	
	
	
	

}
