package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements LoginDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean loginValidate(Integer customerId, String customerPwd) {
		
		Query query = entityManager.createQuery("FROM Customer WHERE customerId=? and customerPwd=?");
		query.setParameter(0, customerId);
		query.setParameter(1, customerPwd);
		
		List<Customer> customer = query.getResultList();
		
		if(customer.isEmpty()) {
			return false;
		}
	  return true;
	}

	@Override
	public String getcustomerName(Integer customerId) {
		Query query = entityManager.createQuery("SELECT firstName FROM Customer WHERE customerId=?");
		query.setParameter(0, customerId);
		
		List<String> customer = query.getResultList();
		
		return customer.get(0);
	}

	
}
