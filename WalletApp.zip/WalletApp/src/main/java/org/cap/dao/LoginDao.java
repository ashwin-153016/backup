package org.cap.dao;

public interface LoginDao {

	boolean loginValidate(Integer customerId, String customerPwd);
	public String getcustomerName(Integer customerId);
}
