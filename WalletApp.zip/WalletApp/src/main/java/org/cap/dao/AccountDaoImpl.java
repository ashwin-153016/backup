package org.cap.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDao")
@Transactional
public class AccountDaoImpl implements AccountDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	@Override
	public Customer findCustomer(int customerId) {
		Customer customer = entityManager.find(Customer.class, customerId);
		return customer;
	}
	
	@Transactional
	@Override
	public long getAccountNo() {
		Query query = entityManager.createQuery("SELECT MAX(accountNo) FROM Account");
		List<Long> accountNo = query.getResultList();
		
		if(accountNo.size() != 0) {
			return accountNo.get(0)+1;
		}
		
		return 1001L;
	}
	
	@Transactional
	@Override
	public void createAccount(Account account) {
		entityManager.persist(account);
	}

	@Transactional(readOnly=true)
	@Override
	public List<Account> getAllCustomerAccounts(int customerId) {
		Query query= entityManager.createQuery("FROM Account acc WHERE acc.customer.customerId=:custId");
			query.setParameter("custId", customerId);
			List<Account> accounts= query.getResultList();	
			
		return accounts;
	}

	

	@Transactional
	@Override
	public List<Account> getAllAccounts(int customerId) {
		Query query= entityManager.createQuery("FROM Account WHERE customerId!=?");
		query.setParameter(0, customerId);
		List<Account> accounts= query.getResultList();	
		
	return accounts;
	}

	@Transactional
	@Override
	public void depositWithdraw(Transaction transaction) {
		entityManager.persist(transaction);
	}

	@Transactional
	@Override
	public Account findAccount(long accNo) {
		Query query = entityManager.createQuery("FROM Account WHERE accountNo=?");
		query.setParameter(0, accNo);
		
		List<Account> account = query.getResultList();
		
		return account.get(0);
	}

	@Transactional
	@Override
	public void transferAmount(Transaction transaction) {
		
		entityManager.persist(transaction);
		
	}


	@Transactional(readOnly=true)
	@Override
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId){
	
		
		Query query2=entityManager.createQuery(strQuery);
		
		query2.setParameter("custId", customerId);
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream().collect(Collectors.groupingBy(Transaction::getFromAccount, Collectors.summingDouble(Transaction::getAmount)));
	return map;
	}

	@Override
	public List<Transaction> getTransactions(int customerId) {
		Query query = entityManager.createQuery("FROM Transaction WHERE customerId=:custId");
		query.setParameter("custId", customerId);
		List<Transaction> transactions = query.getResultList();
		return transactions;
	}
	
}
