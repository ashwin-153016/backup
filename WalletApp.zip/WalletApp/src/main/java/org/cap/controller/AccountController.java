package org.cap.controller;

import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.AccountService;
import org.cap.service.LoginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private AccountService accountService;
	
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, @RequestParam("customerId") String id, @RequestParam("customerPwd") String customerPwd,HttpSession session) {
		
		int customerId = Integer.parseInt(id);
		
		if(loginService.loginValidate(customerId, customerPwd)) {
			
			String name = loginService.getCustomerName(customerId);
			map.put("customerName", name);
			session.setAttribute("customerId", customerId);
			return "main";
		}
		return "redirect:/";
	}
	

	@RequestMapping("/welcomePage")
	public String welcomePage(ModelMap map, HttpSession session) {
	
		String name = loginService.getCustomerName(Integer.parseInt(session.getAttribute("customerId").toString()));
		map.put("customerName", name);

		return "welcomePage";
	}
	

	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {
		map.put("account", new Account());
		return "createAccount";
	}
	
	@RequestMapping("/showBalance")
	public String showBalanceDetails(ModelMap map,
			HttpSession session) {
		
		Integer custId= Integer.parseInt(session.getAttribute("customerId").toString());
		List<Account> accounts= accountService.getAccountWithBalance(custId);
		
		map.put("accounts", accounts);
		
		return "showBalance";
	}
	
	@RequestMapping("/depositWithdraw")
	public String showDepositPage(ModelMap map, HttpSession session) {
		
		Integer customerId = Integer.parseInt(session.getAttribute("customerId").toString());
		List<Account> customerAccountList = accountService.getAllCustomerAccounts(customerId);
		
		map.put("customerAccounts", customerAccountList);
		map.put("transaction1", new Transaction());
		
		return "depositWithdraw";
	}

	@RequestMapping("/fundTransfer")
	public String showFundTransferPage(ModelMap map, HttpSession session) {
		
		Integer customerId = Integer.parseInt(session.getAttribute("customerId").toString());
		
		List<Account> customerAccountList = accountService.getAllCustomerAccounts(customerId);
		List<Account> allAccountList = accountService.getAllAccounts(customerId);
		
		map.put("customerAccounts", customerAccountList);
		map.put("allAccounts", allAccountList);
		map.put("transaction", new Transaction());
		
		return "fundTransfer";
	}

	@RequestMapping("/printTransaction")
	public String showPrintTransactionPage(ModelMap map, HttpSession session) {
		List<Transaction> transactions = accountService.getTransactions(Integer.parseInt(session.getAttribute("customerId").toString()));
		map.put("transactions", transactions);
		
		return "printTransaction";
	}

	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
	 return "redirect:/";
	}
	
	@PostMapping("/saveAccount")
	public String saveAccount(@ModelAttribute("account") Account account, HttpSession session) {
		
		Customer customer = accountService.findCustomer(Integer.parseInt(session.getAttribute("customerId").toString()));
		
		account.setOpeningDate(new Date());
		account.setCustomer(customer);
		
		long acc = accountService.getAccountNo(); 
		
		account.setAccountNo(acc);
		account.setStatus("active");
		
		accountService.createAccount(account);
		
		
		return "redirect:createAccount";
	}
	
	@PostMapping(value="/depositWithdrawAmount")
	public String depositWithdrawAmount(@ModelAttribute("transaction1")Transaction transaction,ModelMap map, HttpSession session) {
		
		Integer customerId=Integer.parseInt(session.getAttribute("customerId").toString());
		Customer customer= accountService.findCustomer(customerId);
		
		transaction.setTransactionDate(new Date());
		transaction.setStatus("successful");
		transaction.setCustomer(customer);
		
		long accNo=transaction.getFromAccount().getAccountNo();
		
		Account account=accountService.findAccount(accNo);
		transaction.setFromAccount(account);
	
		accountService.depositWithdraw(transaction);
		
		return "redirect:depositWithdraw";
	}
	
	@PostMapping("/transferAmount")
	public String transferAmount(@ModelAttribute("transaction")Transaction transaction, ModelMap map, HttpSession session) {
		
		Integer customerId=Integer.parseInt(session.getAttribute("customerId").toString());
		Customer customer= accountService.findCustomer(customerId);
		
		transaction.setTransactionDate(new Date());
		transaction.setStatus("successful");
		transaction.setCustomer(customer);
		transaction.setTransactionType("debit");
	
		long accNo=transaction.getFromAccount().getAccountNo();
		Account account=accountService.findAccount(accNo);
		transaction.setFromAccount(account);
		
		long accNo1=transaction.getToAccount().getAccountNo();
		Account account1=accountService.findAccount(accNo1);
		transaction.setToAccount(account1);
		
		accountService.transferAmount(transaction);
		
		return "redirect:fundTransfer";
	}



}
