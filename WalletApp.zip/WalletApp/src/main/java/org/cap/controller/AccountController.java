package org.cap.controller;

import org.cap.service.LoginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {

	@Autowired
	private LoginService loginService;

	
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, @RequestParam("customerId") String id, @RequestParam("customerPwd") String customerPwd) {
		
		int customerId = Integer.parseInt(id);
		
		if(loginService.loginValidate(customerId, customerPwd)) {
			
			String name = loginService.getcustomerName(customerId);
			map.put("customerName", name);
			
			return "main";
		}
		return "redirect:/";
	}
	
	
	

	@RequestMapping("/createAccount")
	public String showCreateAccountPage() {
		return "createAccount";
	}
	
	@RequestMapping("/showBalance")
	public String showBalancePage() {
		return "showBalance";
	}

	@RequestMapping("/deposit")
	public String showDepositPage() {
		return "deposit";
	}

	@RequestMapping("/withdraw")
	public String showWithdrawPage() {
		return "withdraw";
	}

	@RequestMapping("/fundTransfer")
	public String showFundTransferPage() {
		return "fundTransfer";
	}

	@RequestMapping("/printTransaction")
	public String showPrintTransactionPage() {
		return "printTransaction";
	}

	
	
	
	
	
	
}
