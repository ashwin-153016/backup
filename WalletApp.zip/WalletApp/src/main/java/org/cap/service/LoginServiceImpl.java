package org.cap.service;

import org.cap.dao.LoginDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDao loginDao;
	
	@Override
	public boolean loginValidate(Integer customerId, String customerPwd) {
		
		return loginDao.loginValidate(customerId, customerPwd);
	}

	@Override
	public String getcustomerName(Integer customerId) {
		return loginDao.getcustomerName(customerId);
	}

}
