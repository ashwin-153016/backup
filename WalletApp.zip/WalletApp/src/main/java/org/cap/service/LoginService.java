package org.cap.service;

public interface LoginService {

	boolean loginValidate(Integer customerId, String customerPwd);
	
	public String getcustomerName(Integer customerId);
}
