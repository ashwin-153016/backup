package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {

	private WebDriver driver;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	
	@Given("^Open login page$")
	public void open_login_page() throws Throwable {
		driver.get("http://localhost:8082/WalletApp/");
	}

	@When("^Username and password valid$")
	public void username_and_password_valid() throws Throwable {
		WebElement element=driver.findElement(By.name("customerId"));
		element.sendKeys("1001");
		WebElement element1=driver.findElement(By.name("customerPwd"));
		element1.sendKeys("myPassword");
		element.submit();
	}

	@Then("^Navigate to main page$")
	public void navigate_to_main_page() throws Throwable {
		//driver.get("http://localhost:8081/WalletSpring/login");
	}
}
