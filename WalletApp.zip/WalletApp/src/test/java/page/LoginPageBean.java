package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {

	WebDriver driver;
	/*private By userName = By.name("customerId");
	private By userPassword = By.name("customerPwd");
	private By submitLogin = By.name("login");*/
	
	//private By pageHeading = By.xpath("//*[@id=\"mainCnt\"]/h1");
	
	@FindBy(name="customerId",how=How.NAME)
	private WebElement userName;
	
	@FindBy(name="customerPwd")
	private WebElement userPassword;
	
	@FindBy(name="login")
	private	WebElement submitLogin; 
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/h1")
	private WebElement pageHeading;
	
	
	
	public LoginPageBean(WebDriver driver) {
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	public void setUserName(String usrName) {
		//driver.findElement(userName).sendKeys(usrName);
	  userName.sendKeys(usrName);
	}
	
	public void setUserPwd(String usrPwd) {
		//driver.findElement(userPassword).sendKeys(usrPwd);
	  userPassword.sendKeys(usrPwd);
	}
	
	public void setSubmitLogin() {
		//driver.findElement(submitLogin).submit();
	  submitLogin.submit();
	}
	
	public String getPageTitle() {
		//return driver.findElement(pageHeading).getText();
		return pageHeading.getText();
	}
	
	public void loginTo_NextPage(String userName, String password) {
		this.setUserName(userName);
		this.setUserPwd(password);
		this.setSubmitLogin();
	}
}
