package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public class PilotDaoImpl implements PilotDao{
	
	private static AtomicInteger pilotId=new AtomicInteger(1000);
	
	 
	private static List<Pilot> pilots=dummyDbPilot();
	
	private static List<Pilot> dummyDbPilot(){
		List<Pilot> pilots=new ArrayList<>();
		
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Tom", "Jerry", new Date(1991-1900, 3, 12), new Date(), true, 23000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Jack", "Jerry", new Date(1997-1900, 6, 19), new Date(), true, 34000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Jessi", "Jerry", new Date(1987-1900, 3, 23), new Date(2013,3,12), false, 21321));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Ram", "Singh", new Date(1991-1900, 10, 12), new Date(2019,1,12), true, 670000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Vishal", "Singh", new Date(1991-1900, 11, 10), new Date(), false, 90000));
		
		return pilots;
	}

	@Override
	public List<Pilot> getAllPilots() {
		
		return pilots;
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
	
		for (Pilot pilot : pilots) {
			if(pilot.getPilotId() == pilotId) {
				return pilot;
			}
		}
		return null;
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		
		Iterator<Pilot> pIter = pilots.iterator();
		boolean flag = false;
		
		while(pIter.hasNext()) {
			if(pIter.next().getPilotId() == pilotId) {
				pIter.remove();
				flag = true;
				break;
			}
		}
		if(flag == true)
			return pilots;
		else
			return null;
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		pilots.add(pilot);
		return pilots;
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		
		for(Pilot plt : pilots) {
			if( plt.getPilotId() == pilot.getPilotId()) {
				int index = pilots.indexOf(plt);
				pilots.remove(index);
				pilots.add(index, pilot);
				return pilots;
			}
		}
		pilots.add(pilot);
		return pilots;
	}

}
