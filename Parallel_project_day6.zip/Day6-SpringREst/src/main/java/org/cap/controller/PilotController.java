package org.cap.controller;

import java.util.List;

import org.cap.model.Pilot;
import org.cap.service.PilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class PilotController {
	
	@Autowired
	private PilotService pilotService;

	@GetMapping("/pilots")
	public ResponseEntity<List<Pilot>> getAllPilots(){
		
		List<Pilot> pilots= pilotService.getAllPilots();
		
		if(pilots.isEmpty() || pilots==null)
			return new ResponseEntity("Sorry! Pilot Details not Available.", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	@GetMapping("/pilots/{pilotId}")
	public ResponseEntity<Pilot> findPilot(@PathVariable("pilotId") Integer pilotId){
		
		Pilot pilots = pilotService.findPilot(pilotId);
		
		if(pilots == null) {
			return new ResponseEntity("Sorry! Pilot Details not Available.", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Pilot>(pilots, HttpStatus.OK);
	}
	
	@DeleteMapping("/pilots/{pilotId}")
	public ResponseEntity<List<Pilot>> deletePilot(@PathVariable("pilotId") Integer pilotId){
		
		List<Pilot> pilots = pilotService.deletePilot(pilotId);
		
		if(pilots == null) {
			return new ResponseEntity("Sorry! Pilot Details not Available.", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	@PostMapping("/pilots/{pilotId}")
	public ResponseEntity<List<Pilot>> createPilot(@RequestBody Pilot pilot){
		List<Pilot> pilots = pilotService.createPilot(pilot);
		
		if(pilots == null) {
			return new ResponseEntity("Error in creating new Pilot!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	@PutMapping("/pilots/{pilotId}")
	public ResponseEntity<List<Pilot>> updatePilot(@RequestBody Pilot pilot){
		List<Pilot> pilots = pilotService.updatePilot(pilot);
		
		if(pilots.isEmpty() || pilots == null) {
			return new ResponseEntity("Sorry, Pilot not found", HttpStatus.NOT_FOUND); 
		}
	 return new ResponseEntity<List<Pilot>>(pilots,HttpStatus.OK);
	}
}
