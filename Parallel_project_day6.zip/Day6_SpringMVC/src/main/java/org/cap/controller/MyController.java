package org.cap.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController 
{

	public String sayHello() {
		return null;
		
	}
}