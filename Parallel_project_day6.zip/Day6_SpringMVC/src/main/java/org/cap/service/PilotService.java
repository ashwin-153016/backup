package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;

public interface PilotService {

	public List<Pilot> getAllPilots();
}
