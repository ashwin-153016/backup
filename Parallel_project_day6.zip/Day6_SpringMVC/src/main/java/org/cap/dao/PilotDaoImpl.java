package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public class PilotDaoImpl implements PilotDao {
	
	private static AtomicInteger pilotId = new AtomicInteger(1000);

	private static List<Pilot> pilots = dummyDbPilot();
	
	private static List<Pilot> dummyDbPilot() {
		List<Pilot> pilot = new ArrayList<>();
		
		pilot.add(new Pilot(pilotId.incrementAndGet(),"Tom","Jerry",new Date(), new Date(),true,25000));
		
		return pilot;
	}
	
	@Override
	public List<Pilot> getAllPilots() {
		
		return pilots;
	}
	

	
	
}
