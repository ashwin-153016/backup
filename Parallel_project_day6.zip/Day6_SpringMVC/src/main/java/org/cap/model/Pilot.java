package org.cap.model;



import java.util.Date;


public class Pilot {

	private int pilotId;
	private String firstName;
	private String lastName;
	private Date dateOfbirth;
	private Date dateOfJoining;
	private Boolean isCertified;
	private double salary;
	
	
	public Pilot() {
		super();
	}
	
	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateOfbirth() {
		return dateOfbirth;
	}
	public void setDateOfbirth(Date dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public Boolean getIsCertified() {
		return isCertified;
	}
	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfbirth="
				+ dateOfbirth + ", dateOfJoining=" + dateOfJoining + ", isCertified=" + isCertified + ", salary="
				+ salary + "]";
	}
	public Pilot(int pilotId, String firstName, String lastName, Date dateOfbirth, Date dateOfJoining,
			Boolean isCertified, double salary) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfbirth = dateOfbirth;
		this.dateOfJoining = dateOfJoining;
		this.isCertified = isCertified;
		this.salary = salary;
	}
	
	
}