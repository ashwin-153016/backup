package org.cap.service;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface AccountService {

	public Customer findCustomer(int customerId);

	public long getAccountNo();

	public void createAccount(Account account);

}
