package org.cap.service;

import org.cap.dao.AccountDao;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountService")
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao accountDao;
	
	@Override
	public Customer findCustomer(int customerId) {
		return accountDao.findCustomer(customerId);
	}

	@Override
	public long getAccountNo() {
		return accountDao.getAccountNo();
	}

	@Override
	public void createAccount(Account account) {
		accountDao.createAccount(account);
	}

}
