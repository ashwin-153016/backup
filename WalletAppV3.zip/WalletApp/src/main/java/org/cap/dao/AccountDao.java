package org.cap.dao;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface AccountDao {

	public Customer findCustomer(int customerId);

	public long getAccountNo();

	public void createAccount(Account account);

}
