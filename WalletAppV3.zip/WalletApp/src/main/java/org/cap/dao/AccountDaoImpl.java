package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDao")
@Transactional
public class AccountDaoImpl implements AccountDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Customer findCustomer(int customerId) {
		Customer customer = entityManager.find(Customer.class, customerId);
		return customer;
	}

	@Override
	public long getAccountNo() {
		Query query = entityManager.createQuery("SELECT MAX(accountNo) FROM Account");
		List<Long> accountNo = query.getResultList();
		
		if(accountNo.size() != 0) {
			return accountNo.get(0)+1;
		}
		
		return 1001L;
	}

	@Override
	public void createAccount(Account account) {
		entityManager.persist(account);
	}

	
}
