package org.cap.exception;

public class InsufficientBalance extends Exception {
	public InsufficientBalance(String msg) {
		super(msg);
	}
}
