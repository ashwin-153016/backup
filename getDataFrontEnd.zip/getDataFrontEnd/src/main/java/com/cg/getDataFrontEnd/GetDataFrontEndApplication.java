package com.cg.getDataFrontEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetDataFrontEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetDataFrontEndApplication.class, args);
	}
}
